// tslint:disable-next-line: class-name
export class Employees
 {
   public name: string;
   public Age: string;
   public Gender: string;
   public Maratial: string;

   constructor( name: string, Age: string, Gender: string, Maratial: string){
  this.name = name;
  this.Age = Age;
  this.Gender = Gender;
  this.Maratial = Maratial;
  }
 }

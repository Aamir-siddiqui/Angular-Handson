import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
userid = 'test';
password = 'test1';
  constructor() { }

  ngOnInit(): void {
  }

  // tslint:disable-next-line: typedef
  Login(uid: string, upass: string)
  {

  }
}

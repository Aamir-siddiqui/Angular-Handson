import { Component, OnInit } from '@angular/core';

import employee from '../json/employee.json';
import { Employees } from './../employee.model';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
// tslint:disable-next-line: variable-name
// let object_employee = new Object();
export class HomeComponent implements OnInit {
public employee: {name: string, Age: string, Gender: string, Maratial: string} = employee;
public editemployee: {name: string, Age: string, Gender: string, Maratial: string};
edit = false;
add = false;
name: string;
 Age: string;
 Gender: string;
Maratial: string;
employees: Employees[] = [new Employees(this.name, this.Age, this.Gender, this.Maratial)];
//  public editinfo: [];
// tslint:disable-next-line: variable-name

constructor() { }

  // tslint:disable-next-line: typedef
ngOnInit(){
  }
  // tslint:disable-next-line: typedef
onEditclick(index: number)
  {
    console.log(index);
    // tslint:disable-next-line: typedef
    employee.find(() => {
         // tslint:disable-next-line: no-unused-expression
         this.edit = true;
         console.log(employee[index]);
       // tslint:disable-next-line: align
       return employee[index];

    });
  }
  // tslint:disable-next-line: typedef
     onAddclick()
     {
        this.add = true;
      }
// tslint:disable-next-line: comment-format
//tslint:disable-next-line: typedef
  addTolist()
  {

  }



}
